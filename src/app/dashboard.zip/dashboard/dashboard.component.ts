import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CdsButtonModule, CdsIconModule, CdsDividerModule } from '@cds/angular';
import { GoogleMapsModule } from '@angular/google-maps';
import { PieChart01Component } from "../widgets/pie-chart-01/pie-chart-01.component";
import { BarChart01Component } from "../widgets/bar-chart-01/bar-chart-01.component";

const grayMapStyle: google.maps.MapTypeStyle[] = [
  {
    featureType: 'all',
    elementType: 'all',
    stylers: [
      { saturation: -50 }, // Desaturate all colors
      { lightness: 0 }      // Optional: tweak brightness
    ]
  }
];

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  imports: [
    CommonModule,
    CdsButtonModule,
    CdsIconModule,
    CdsDividerModule,
    GoogleMapsModule,
    PieChart01Component,
    BarChart01Component
  ]
})
export class DashboardComponent implements OnInit, OnDestroy {


  items = [
    "FCPR MAX ESPOIR",
    "FCPR MAXULA CROISSANCE ENTREPRISES",
    "FCPR MAXULA CAPITAL RETOURNEMENT",
    "FCPR MAXULA JASMIN",
    "FCPR CAPITAL RETOURNEMENT",
    "FCPR MAXULA JASMIN PMN",
    "START UP MAXULA SEED FUND"
  ].sort();

  map_width = "1200px";
  map_height = "400px";

  pager = {
    currentPage: 1,
    itemsPerPage: 10,
    totalItems: this.items.length
  };

  progressValues = [
    { value: 0, status: 'info', title: 'Investissement', color: '#23ccf1' },
    { value: 0, status: 'success', title: 'Retour', color: '#28a745' },
    { value: 0, status: 'warning', title: 'Risque', color: '#ffc107' },
    { value: 0, status: 'danger', title: 'Alerte', color: '#dc3545' }
  ];

  interval: any;
  mapOptions = {
    styles: grayMapStyle,
    disableDefaultUI: false,
  };

  ngOnInit() {
    this.startProgressAnimations();

    setTimeout(() => {
      this.map_width = document.getElementById("map_container")?.clientWidth + "px" || "1200px";
      this.map_height = document.getElementById("map_container")?.clientHeight + "px" || "500px";
    });

  }

  @HostListener('window:resize', ['$event'])
  onresize(event: any) {
    const mapContainer = document.getElementById("map_container");
    this.map_width = mapContainer ? mapContainer.clientWidth + "px" : "1200px";
    this.map_height = mapContainer ? mapContainer.clientHeight + "px" : "500px";
  }


  ngOnDestroy() {
    if (this.interval) {
      clearInterval(this.interval);
    }
  }

  startProgressAnimations() {
    this.interval = setInterval(() => {
      this.progressValues.forEach((progress, index) => {
        progress.value = (progress.value + 5) % 100;
      });
    }, 1000);
  }

  get totalPages(): number {
    return Math.ceil(this.pager.totalItems / this.pager.itemsPerPage);
  }

  constructor() {
    this.updatePager();
  }

  updatePager() {
    this.pager.totalItems = this.items.length;
  }

  previousPage() {
    if (this.pager.currentPage > 1) {
      this.pager.currentPage--;
    }
  }

  nextPage() {
    const totalPages = Math.ceil(this.pager.totalItems / this.pager.itemsPerPage);
    if (this.pager.currentPage < totalPages) {
      this.pager.currentPage++;
    }
  }
}
